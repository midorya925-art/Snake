package com.example.snake;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new SnakeView(this));
    }
}

class SnakeView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    ArrayList<Point> snake = new ArrayList<>();
    Point food = new Point();
    int dir = 1, score = 0;
    boolean over = false;
    Random random = new Random();
    long last = 0;
    float downX, downY;

    SnakeView(Context c) {
        super(c);
        p.setTypeface(Typeface.create("sans", Typeface.BOLD));
        reset();
    }

    void reset() {
        snake.clear();
        snake.add(new Point(10, 10));
        snake.add(new Point(9, 10));
        snake.add(new Point(8, 10));
        dir = 1; score = 0; over = false;
        placeFood();
        invalidate();
    }

    void placeFood() {
        do {
            food.x = random.nextInt(20);
            food.y = random.nextInt(28);
        } while (snake.contains(food));
    }

    protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(Color.rgb(18,18,18));
        float cell = Math.min(getWidth()/20f, (getHeight()-130)/28f);
        float ox = (getWidth()-20*cell)/2f, oy = 70;

        p.setColor(Color.WHITE); p.setTextSize(34); p.setTextAlign(Paint.Align.CENTER);
        c.drawText("SCORE: " + score, getWidth()/2f, 42, p);

        p.setColor(Color.rgb(220,70,70));
        c.drawCircle(ox+(food.x+.5f)*cell, oy+(food.y+.5f)*cell, cell*.38f, p);

        for (int i=0;i<snake.size();i++) {
            Point s=snake.get(i);
            p.setColor(i==0 ? Color.rgb(100,220,100) : Color.rgb(45,170,70));
            c.drawRoundRect(ox+s.x*cell+2, oy+s.y*cell+2,
                    ox+(s.x+1)*cell-2, oy+(s.y+1)*cell-2, cell*.2f, cell*.2f, p);
        }

        if (over) {
            p.setColor(Color.argb(190,0,0,0)); c.drawRect(0,0,getWidth(),getHeight(),p);
            p.setColor(Color.WHITE); p.setTextSize(42);
            c.drawText("GAME OVER", getWidth()/2f, getHeight()/2f-20, p);
            p.setTextSize(24); c.drawText("Tap to restart", getWidth()/2f, getHeight()/2f+30, p);
        }

        if (!over && System.currentTimeMillis()-last > 130) {
            move(); last=System.currentTimeMillis(); invalidate();
        } else if (!over) postInvalidateDelayed(20);
    }

    void move() {
        Point h = new Point(snake.get(0));
        if(dir==0) h.y--; if(dir==1) h.x++; if(dir==2) h.y++; if(dir==3) h.x--;
        if(h.x<0||h.x>=20||h.y<0||h.y>=28||snake.contains(h)) { over=true; return; }
        snake.add(0,h);
        if(h.equals(food)) { score++; placeFood(); } else snake.remove(snake.size()-1);
    }

    public boolean onTouchEvent(android.view.MotionEvent e) {
        if(e.getAction()==0){downX=e.getX();downY=e.getY();return true;}
        if(e.getAction()==1){
            if(over){reset();return true;}
            float dx=e.getX()-downX, dy=e.getY()-downY;
            if(Math.abs(dx)>Math.abs(dy) && Math.abs(dx)>30) {
                if(dx>0 && dir!=3) dir=1; else if(dx<0 && dir!=1) dir=3;
            } else if(Math.abs(dy)>30) {
                if(dy>0 && dir!=0) dir=2; else if(dy<0 && dir!=2) dir=0;
            }
            return true;
        }
        return true;
    }
}
